document.addEventListener('DOMContentLoaded', function () {
  // Admin Dropdown
  const adminBtn = document.getElementById('adminBtn');
  const adminDropdown = document.getElementById('adminDropdown');
  if (adminBtn) {
    adminBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      adminDropdown.classList.toggle('show');
    });
  }
  document.addEventListener('click', function (e) {
    if (!e.target.closest('#adminBtn')) {
      adminDropdown && adminDropdown.classList.remove('show');
    }
  });

  // Scroll highlight
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = {
    '#welcome': document.getElementById('welcome'),
    '#description': document.getElementById('description'),
    '#sdg-heading': document.getElementById('sdg-heading')
  };
  window.addEventListener('scroll', () => {
    let scrollPos = window.scrollY + 150;
    navLinks.forEach(link => {
      const sec = sections[link.getAttribute('href')];
      if (sec && scrollPos >= sec.offsetTop && scrollPos < sec.offsetTop + sec.offsetHeight) {
        navLinks.forEach(l => l.classList.remove('nav-active'));
        link.classList.add('nav-active');
      }
    });
  });

  // Clock
  (function initClock(){
    const el = document.getElementById('clock');
    if (!el) return;
    function tick(){
      const now = new Date();
      el.textContent = now.toLocaleTimeString() + ' | ' + now.toLocaleDateString();
    }
    tick();
    setInterval(tick,1000);
  })();

  // Reveal description cards
  (function revealDescCards(){
    const cards = Array.from(document.querySelectorAll('.desc-card'));
    if(!cards.length) return;
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if(entry.isIntersecting){
          const idx = cards.indexOf(entry.target);
          entry.target.style.transitionDelay = (idx * 0.12) + 's';
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    },{ threshold: 0.22 });
    cards.forEach(c => observer.observe(c));
  })();

  // SDG cards reveal
  (function revealSdgCards(){
    const cards = Array.from(document.querySelectorAll('.sdg-card'));
    cards.forEach((card, i) => {
      card.style.opacity = 0;
      card.style.transform = 'translateY(30px)';
      setTimeout(() => {
        card.style.transition = 'transform .5s, opacity .45s';
        card.style.opacity = 1;
        card.style.transform = 'translateY(0)';
      }, 300 + (i * 90));
    });
  })();

  // Barangay data + graph behavior
  const barangays = [
    "San Lucas","Bugtong Na Pulo","Plaridel","Inosloban","Lumbang","Bulacnin",
    "Pusil","Tanguay","Talisay","San Salvador","Dagatan","Marauoy","Santo Niño",
    "Tibig","Balintawak","Munting Pulo","Sapac","Pinagkawitan","Sabang",
    "San Carlos","Bagong Pook","Halang","Poblacion Barangay 3","Sico",
    "Poblacion Barangay 2","Mataas Na Lupa","Anilao","Poblacion Barangay 5",
    "Poblacion Barangay 10","Bulaklakan","Poblacion Barangay 4",
    "Poblacion Barangay 1","Malitlit","Bolbok","Tambo","Sampaguita","Mabini",
    "Poblacion Barangay 6","Poblacion Barangay 7","Tangob","San Sebastian",
    "San Benito","San Jose","Duhatan","Banaybanay","Lodlod","Latag",
    "Pinagtongulan","Antipolo del Norte","Kayumanggi"
  ];
  function sdgPercentage(index, sdgIndex){
    const x = Math.abs(Math.sin((index + 1) * (sdgIndex + 1) * 12.345)) * 100;
    return Math.floor((x % 85) + 10);
  }

  let chartInstance = null;
  const sdgGraphBox = document.getElementById('sdgGraphBox');
  const sdgTitle = document.getElementById('sdgTitle');
  const sdgSub   = document.getElementById('sdgSub');
  const sdgCanvasEl = document.getElementById('sdgBarGraph');
  const tableBody = document.getElementById('tableBody');
  const tableWrap = document.getElementById('tableWrap');
  const chartWrap = document.getElementById('chartWrap');

  function openSDG(id){
    if(!sdgCanvasEl) return;
    const ctx = sdgCanvasEl.getContext('2d');
    const labels = [];
    const values = [];
    barangays.forEach((b, i)=>{ labels.push(b); values.push(sdgPercentage(i, id-1)); });

    sdgTitle.textContent = `SDG ${id} — Barangay Percentages`;
    sdgSub.textContent = `Showing deterministic demo percentages for SDG ${id}.`;
    sdgGraphBox && sdgGraphBox.classList.add('show');

    tableBody.innerHTML = '';
    labels.forEach((lab, i) => {
      tableBody.innerHTML += `<tr><td>${lab}</td><td>${values[i]}%</td></tr>`;
    });

    tableWrap.style.display = 'none';
    chartWrap.style.display = 'block';

    if(chartInstance) chartInstance.destroy();
    chartInstance = new Chart(ctx, {
      type: 'bar',
      data: { labels, datasets: [{ data: values, borderRadius: 6, barPercentage: 0.75 }] },
      options: {
        responsive: true,
        scales: { x: { display:false }, y: { beginAtZero:true, max:100 } },
        plugins: { legend:{display:false} },
        animation: { delay: ctx => ctx.dataIndex * 10, duration: 800 }
      }
    });

    setTimeout(()=> { sdgGraphBox && sdgGraphBox.scrollIntoView({behavior:'smooth', block:'center'}); }, 150);
  }

  // Buttons
  const btnCloseGraph = document.getElementById('btnCloseGraph');
  btnCloseGraph && (btnCloseGraph.onclick = () => sdgGraphBox.classList.remove('show'));

  const btnTable = document.getElementById('btnTable');
  if (btnTable) {
    btnTable.onclick = () => {
      if(tableWrap.style.display === 'none'){
        tableWrap.style.display = 'block';
        chartWrap.style.display = 'none';
        btnTable.textContent = "Chart";
      } else {
        tableWrap.style.display = 'none';
        chartWrap.style.display = 'block';
        btnTable.textContent = "Table";
      }
    };
  }

  document.querySelectorAll('.btn-open').forEach(btn => {
    btn.addEventListener('click', (e) => { e.stopPropagation(); openSDG(Number(btn.dataset.sdg)); });
  });
  document.querySelectorAll('.btn-desc').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const target = document.getElementById(btn.dataset.target);
      target && target.classList.toggle('open');
    });
  });

  document.querySelectorAll('.sdg-card').forEach(card => {
    card.addEventListener('click', (e) => {
      if(e.target.closest('.btn-desc')) return;
      openSDG(Number(card.dataset.sdg));
    });
  });

  // Back to top
  window.addEventListener('scroll', () => {
    const back = document.getElementById('backToTop');
    if(!back) return;
    if(window.scrollY > 420) back.classList.add('show'); else back.classList.remove('show');
  });
  const backEl = document.getElementById('backToTop');
  backEl && (backEl.onclick = () => window.scrollTo({top:0, behavior:'smooth'}));
});

// MOBILE MENU TOGGLE
const mobileMenuBtn = document.getElementById("mobileMenuBtn");
const mobileMenu = document.getElementById("mobileMenu");

if (mobileMenuBtn) {
  mobileMenuBtn.addEventListener("click", () => {
    mobileMenu.classList.toggle("hidden");
  });
}

// Close mobile menu on link click
document.querySelectorAll("#mobileMenu a").forEach(link => {
  link.addEventListener("click", () => {
    mobileMenu.classList.add("hidden");
  });
});

// Handle SDG image loading with fallback icons
(function initSDGImages(){
  const sdgImages = document.querySelectorAll('.sdg-image');
  
  sdgImages.forEach(img => {
    img.addEventListener('error', function() {
      // Hide image and show fallback icon
      img.style.display = 'none';
      const container = img.closest('.sdg-image-container');
      const fallback = container.querySelector('.sdg-icon-fallback');
      if (fallback) {
        fallback.style.display = 'flex';
      }
    });
    
    img.addEventListener('load', function() {
      // Hide fallback when image loads
      const container = img.closest('.sdg-image-container');
      const fallback = container.querySelector('.sdg-icon-fallback');
      if (fallback) {
        fallback.style.display = 'none';
      }
    });
  });
})();
