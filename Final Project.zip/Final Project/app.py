from flask import Flask, render_template, request, redirect, session
import sqlite3

app = Flask(__name__)
app.secret_key = "supersecret123"   # change this

def get_db():
    return sqlite3.connect("database.db")

def get_initials(fullname):
    parts = fullname.split()
    initials = "".join([p[0] for p in parts])
    return initials.upper()[:2]

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        try:
            con = get_db()
            con.row_factory = sqlite3.Row
            cur = con.cursor()
            cur.execute("SELECT id, fullname, role, password FROM users WHERE email = ?", (email,))
            user = cur.fetchone()
            con.close()

            if user and password == user[3]:  # You will replace with hashed password later
                session["user_id"] = user[0]
                session["fullname"] = user[1]
                session["role"] = user[2]
                session["avatar"] = get_initials(user[1])

                return redirect("/")

            return render_template("login.html", error="Invalid email or password")
        except sqlite3.OperationalError as e:
            return render_template("login.html", error="Database error. Please try again later.")
        except Exception as e:
            return render_template("login.html", error="An error occurred. Please try again.")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        fullname = request.form.get("fullname")
        email = request.form.get("email")
        password = request.form.get("password")
        confirm_password = request.form.get("confirm_password")

        if password != confirm_password:
            return render_template("register.html", error="Passwords do not match")

        if len(password) < 6:
            return render_template("register.html", error="Password must be at least 6 characters")

        try:
            con = get_db()
            cur = con.cursor()
            
            # Check if email already exists
            cur.execute("SELECT id FROM users WHERE email = ?", (email,))
            if cur.fetchone():
                con.close()
                return render_template("register.html", error="Email already registered")
            
            # Insert new user (default role: user)
            cur.execute("INSERT INTO users (fullname, email, password, role) VALUES (?, ?, ?, ?)",
                       (fullname, email, password, "user"))
            con.commit()
            con.close()
            
            return redirect("/login?registered=true")
        except Exception as e:
            return render_template("register.html", error=f"Registration failed: {str(e)}")

    return render_template("register.html")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/dashboard")
def dashboard():
    if not session.get("user_id"):
        return redirect("/login")
    return render_template("dashboard.html")

@app.route("/manage")
def manage():
    if not session.get("user_id") or session.get("role") != "admin":
        return redirect("/login")
    
    try:
        con = get_db()
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("SELECT id, fullname, email, role FROM users ORDER BY role DESC, fullname")
        users = cur.fetchall()
        
        # Count stats
        cur.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
        admins_count = cur.fetchone()[0]
        
        cur.execute("SELECT COUNT(*) FROM users WHERE role = 'user'")
        regular_users_count = cur.fetchone()[0]
        
        con.close()
        
        return render_template("manage.html", users=users, admins_count=admins_count, regular_users_count=regular_users_count)
    except Exception as e:
        return render_template("manage.html", users=[], admins_count=0, regular_users_count=0, error_message="Error loading users")

@app.route("/add-user", methods=["POST"])
def add_user():
    if not session.get("user_id") or session.get("role") != "admin":
        return redirect("/login")
    
    try:
        fullname = request.form.get("fullname")
        email = request.form.get("email")
        password = request.form.get("password")
        role = request.form.get("role", "user")
        
        con = get_db()
        cur = con.cursor()
        cur.execute("INSERT INTO users (fullname, email, password, role) VALUES (?, ?, ?, ?)",
                   (fullname, email, password, role))
        con.commit()
        con.close()
        
        return redirect("/manage?success=User added successfully")
    except sqlite3.IntegrityError:
        return redirect("/manage?error=Email already exists")
    except Exception as e:
        return redirect("/manage?error=Error adding user")

@app.route("/delete-user/<int:user_id>", methods=["POST"])
def delete_user(user_id):
    if not session.get("user_id") or session.get("role") != "admin":
        return redirect("/login")
    
    # Prevent deleting yourself
    if user_id == session.get("user_id"):
        return redirect("/manage?error=Cannot delete your own account")
    
    try:
        con = get_db()
        cur = con.cursor()
        cur.execute("DELETE FROM users WHERE id = ?", (user_id,))
        con.commit()
        con.close()
        
        return redirect("/manage?success=User deleted successfully")
    except Exception as e:
        return redirect("/manage?error=Error deleting user")

@app.route("/statistics")
def statistics():
    if not session.get("user_id"):
        return redirect("/login")
    
    try:
        con = get_db()
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        
        # Get user counts
        cur.execute("SELECT COUNT(*) FROM users")
        total_users = cur.fetchone()[0]
        
        cur.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
        admin_count = cur.fetchone()[0]
        
        cur.execute("SELECT COUNT(*) FROM users WHERE role = 'moderator'")
        moderator_count = cur.fetchone()[0]
        
        cur.execute("SELECT COUNT(*) FROM users WHERE role = 'user'")
        regular_user_count = cur.fetchone()[0]
        
        con.close()
        
        # Calculate percentages
        admin_percentage = round((admin_count / total_users * 100)) if total_users > 0 else 0
        moderator_percentage = round((moderator_count / total_users * 100)) if total_users > 0 else 0
        regular_percentage = round((regular_user_count / total_users * 100)) if total_users > 0 else 0
        
        # Calculate active sessions (simulated)
        active_sessions = max(1, int(total_users * 0.3))
        active_percentage = round((active_sessions / total_users * 100)) if total_users > 0 else 0
        
        # Growth simulation
        user_growth = 12
        
        # Weekly user registration data (simulated growth trend)
        week1_users = max(1, total_users // 6)
        week2_users = max(1, int(week1_users * 1.2))
        week3_users = max(1, int(week2_users * 1.3))
        week4_users = max(1, int(week3_users * 1.15))
        week5_users = max(1, int(week4_users * 1.25))
        week6_users = max(1, int(week5_users * 1.1))
        
        # Database size (simulated)
        db_size = 245
        
        # Last updated
        from datetime import datetime
        last_updated = datetime.now().strftime("%H:%M")
        
        return render_template(
            "statistics.html",
            total_users=total_users,
            admin_count=admin_count,
            moderator_count=moderator_count,
            regular_user_count=regular_user_count,
            admin_percentage=admin_percentage,
            moderator_percentage=moderator_percentage,
            regular_percentage=regular_percentage,
            active_sessions=active_sessions,
            active_percentage=active_percentage,
            user_growth=user_growth,
            week1_users=week1_users,
            week2_users=week2_users,
            week3_users=week3_users,
            week4_users=week4_users,
            week5_users=week5_users,
            week6_users=week6_users,
            db_size=db_size,
            last_updated=last_updated
        )
    except Exception as e:
        return render_template("statistics.html", error=f"Error loading statistics: {str(e)}")

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
